#define CATCH_CONFIG_MAIN
#include "catch.hpp"

#include "deque.hpp"
#include "linked_list.hpp"

// TODO

TEST_CASE( "Test Front", "[deque]" ) {
//typedef SortedList<int, DynamicArrayList<int> > SortedListType;
//typedef PriorityQueue<int, SortedListType>  PriorityQueueType;
// PriorityQueueType pq;
    
typedef Deque<int> DequeType;

DequeType dq;

REQUIRE(dq.isEmpty());
for(int x = 1; x <= 10; x++){
  dq.pushFront(x);
  REQUIRE(dq.isEmpty() == false);
}
for(int x = 10; x >= 1; x--){
  REQUIRE(dq.front() == x);
  dq.popFront();
}
REQUIRE(dq.isEmpty());
}

TEST_CASE( "Test Back", "[deque]" ) {
//typedef SortedList<int, DynamicArrayList<int> > SortedListType;
//typedef PriorityQueue<int, SortedListType>  PriorityQueueType;
// PriorityQueueType pq;
    
typedef Deque<int> DequeType;

DequeType dq;

REQUIRE(dq.isEmpty());
for(int x = 1; x <= 10; x++){
  dq.pushBack(x);
  REQUIRE(dq.isEmpty() == false);
}
for(int x = 10; x >= 1; x--){
  REQUIRE(dq.back() == x);
  dq.popBack();
}
REQUIRE(dq.isEmpty());
}
