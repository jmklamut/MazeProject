#include <iostream>

#include "image.h"
#include "deque.hpp"

struct State{
  int row;
  int column;
};

int searchForRedWidth(Image<Pixel> input){
for(int x = 0; x < input.width(); x++){
  for(int y = 0; y <input.height(); y++){
    if(input(x,y) == RED){
      return x;
    }
  }
}
return 0;
}

int searchForRedHeight(Image<Pixel> input){
for(int x = 0; x < input.width(); x++){
  for(int y = 0; y <input.height(); y++){
    if(input(x,y) == RED){
      return y;
    }
  }
}
return 0;
}

bool ifGoal(int i, int j, int max_column, int max_row){
  if(i == 0 || j == 0 || i == max_row || j == max_column){ 
    return true;
}
 return false;
}

bool testColor(int i, int j, Image<Pixel> input){
  if(input(i,j) == BLACK){
    return false;
  }
  return true;
}

Image<Pixel> traverse(Image<Pixel> input, Deque<State> d){
  int row = searchForRedWidth(input);
  int column = searchForRedHeight(input);
  int unEx[input.width()][input.height()] = {0};
  State red = {row,column};
  d.pushFront(red);
  while(true){
  if(d.isEmpty()){
    std::cout<< "No Solution Found\n";
    return input;
  }
  State temp = d.front();
  d.popFront();
  State push = {0,0};
  unEx[temp.row][temp.column] = 1;
  if(ifGoal(temp.row,temp.column,input.width()-1,input.height()-1)){
    Image<Pixel> output = input;
    output(temp.row,temp.column) = GREEN;
    std::cout<< "Solution Found\n";
    return output;
  }
  else{
   if(testColor(temp.row+1,temp.column,input)){
    if(unEx[temp.row+1][temp.column]==0){
      push.row = temp.row+1;
      push.column = temp.column;
      d.pushBack(push);
      unEx[temp.row+1][temp.column] = 1;
    }
  }
   if(testColor(temp.row-1,temp.column,input)){
    if(unEx[temp.row-1][temp.column]==0){
      push.row = temp.row-1;
      push.column = temp.column;
      d.pushBack(push);
      unEx[temp.row-1][temp.column] = 1;
    }
   }
   if(testColor(temp.row,temp.column-1,input)){
    if(unEx[temp.row][temp.column-1]==0){
      push.row = temp.row;
      push.column = temp.column-1;
      d.pushBack(push);
      unEx[temp.row][temp.column-1] = 1;
    }
  }
   if(testColor(temp.row,temp.column+1,input)){
    if(unEx[temp.row][temp.column+1]==0){
      push.row = temp.row;
      push.column = temp.column+1;
      d.pushBack(push);
      unEx[temp.row][temp.column+1] = 1;
    }
  }
  }
 }
}

int main(int argc, char *argv[])
{
  
  // get input/output file names from command line arguments
  
  if (argc != 3) {
    std::cout << "Usage: compare"
              << "<first_input_filename> <second_output_filename\n>"
              <<"Input a vaild filename\n"
              << std::endl;
    return EXIT_FAILURE;
  }

  std::string input_file = argv[1];
  std::string output_file = argv[2];


// std::string input_file = "/home/john/starter-code-ece0302/projects/project4/tests/maze02.png";
//std::string output_file = "test02.png";
try{
Image<Pixel> input1 = readFromFile(input_file);

int count = 0;
for(int x = 0; x < input1.width(); x++){
  for(int y = 0; y < input1.height(); y++){
    if(input1(x,y) == RED){
      count++;
    }
    if(input1(x,y) != WHITE && input1(x,y) != RED && input1(x,y) != BLACK){
      std::cout<<"Invalid Color in the loaded maze. Input maze must only have white, red, or black pixels\n"
               << std::endl;
      return EXIT_FAILURE;

    }
  }
}
if(count != 1){
  std::cout<<"The image has more then one or zero red pixels\n";
  return EXIT_FAILURE;
}
 
 Deque<State> dq;

 Image<Pixel> output = traverse(input1,dq);

 writeToFile(output,output_file);

return EXIT_SUCCESS;
}
 catch (std::exception &ex) {
    std::cout<<"Invalid User Input/Couldn't Read or Write Specific File\n"
             <<std::endl;
    return EXIT_FAILURE;
}
} 


